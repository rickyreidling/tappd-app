import React, { useState } from 'react';
import { supabase } from '../utils/supabaseClient';
import { useAppContext } from '@contexts/AppContext';
import { Button } from '@components/ui/button';
import { Input } from '@components/ui/input';

// Helper to upload avatar file
async function uploadProfilePic(file: File, userId: string): Promise<string | null> {
  const fileExt = file.name.split('.').pop();
  const fileName = `${userId}.${fileExt}`;
  const filePath = `${userId}/${fileName}`;
  console.log('Policy expects folder:', userId);
  console.log('Uploading to path:', filePath);

  const { data, error } = await supabase.storage
    .from('avatars')
    .upload(filePath, file, {
      upsert: true,
      contentType: file.type,
    });

  if (error) {
    console.error('Upload failed:', error.message);
    return null;
  }
  return data?.path || filePath;
}

interface EditProfileScreenProps {
  onBack: () => void;
  onSave: () => void;
}

const EditProfileScreen: React.FC<EditProfileScreenProps> = ({ onBack, onSave }) => {
  const { session, userProfile, updateProfile } = useAppContext();
  const user = session?.user;
  const [avatarPath, setAvatarPath] = useState<string | null>(userProfile?.avatar_url || null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && user?.id) {
      const path = await uploadProfilePic(file, user.id);
      if (path) {
        setAvatarPath(path);
        updateProfile({ ...userProfile, avatar_url: path });
      }
    }
  };

  return (
    <div className="p-4">
      <button onClick={onBack}>Back</button>
      <h2>Edit Profile</h2>

      <div>
        <label htmlFor="avatar-upload">Profile Photo</label>
        <Input
          id="avatar-upload"
          type="file"
          accept="image/*"
          onChange={handleFileChange}
        />
        {avatarPath && (<img src={supabase.storage.from('avatars').getPublicUrl(avatarPath).data.publicUrl} alt="Avatar" />)}
      </div>

      {/* other form fields here... */}

      <Button onClick={onSave}>Save Profile</Button>
    </div>
  );
};

export default EditProfileScreen;
